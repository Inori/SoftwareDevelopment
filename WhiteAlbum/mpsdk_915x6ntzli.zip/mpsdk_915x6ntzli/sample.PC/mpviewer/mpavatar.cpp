/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#include <sys/timeb.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>

#if defined(_WIN32) || defined(_WIN64)
#define NOMINMAX
#include <windows.h> // for gl.h
#endif

#include <GL/gl.h>

#include <QtCore>

#include <mprender.h>
#include <mpface.h>
#include <mpctlspeech.h>
#include <mpctlanimation.h>
#include <mpctlitem.h>

#include "mpavatar.h"


//------------------------------------------------------------
// static functions
//------------------------------------------------------------

/**
 * Get current time in milliseconds.
 */
static long getmsec() {
  struct timeb timer;
  ::ftime(&timer);
  long tm = (timer.time * 1000) + timer.millitm;
  return tm;
}

//------------------------------------------------------------
// MpAvatar implementations
//------------------------------------------------------------

/**
 * Constructor
 */
MpAvatar::MpAvatar()
    : isInitialized_(false),
      canRender_(false),
      render_(NULL),
      face_(NULL),
      ctlSpeech_(NULL),
      ctlAnim_(NULL),
      ctlHair_(NULL),
      ctlBeard_(NULL),
      ctlGlasses_(NULL),
      hair_(0),
      beard_(0),
      glasses_(0),
      voice_(0),
      anim_(0),
      animStartTime_(0),
      screenW_(0),
      screenH_(0),
      viewportX_(0),
      viewportY_(0),
      viewportW_(0),
      viewportH_(0),
      zoom_(false),
      drawBackground_(false),
      eventQueue_(),
      nEvent_(0),
      eventQueueLock_()
#ifdef USE_QMEDIAPLAYER
      , mediaPlayer_()
      , mediaContentSpeech_()
#else
      , soundVoice_(NULL)
      , soundAnim_(NULL)
#endif
{

  // create MP instance
  render_ = new motionportrait::MpRender();
  face_ = new motionportrait::MpFace();

  // get controllers
  ctlSpeech_ = face_->GetCtlSpeech();
  ctlAnim_ = face_->GetCtlAnimation();
  ctlHair_ = face_->GetCtlItem(motionportrait::MpFace::ITEM_TYPE_HAIR);
  ctlBeard_ = face_->GetCtlItem(motionportrait::MpFace::ITEM_TYPE_BEARD);
  ctlGlasses_ = face_->GetCtlItem(motionportrait::MpFace::ITEM_TYPE_GLASSES);
}

/**
 * Destructor
 */
MpAvatar::~MpAvatar() {
  cleanupSound();
  delete render_;
  delete face_;
  qDebug("MpAvatar destroyed");
}

/**
 * Initialize avatar.
 *
 * \param compartsPath   path of the common parts directory.
 *
 * \return  MP_SUCCESS if initializing succeeded. otherwise an error code is returned.
 */
int MpAvatar::Initialize(const char *compartsPath) {

  if (isInitialized_) {
    return 0;
  }

  motionportrait::mpRect viewport = { 0, 0, 512, 512 };

  //
  // initialize MpRender
  //
  motionportrait::mpResult ret = render_->Init(compartsPath, viewport);

  if (ret != MP_SUCCESS) {
    qWarning("Failed to initialize motion portrait library");
    return ret;
  }

  render_->EnableDrawBackground(drawBackground_);

  isInitialized_ = true;

  return MP_SUCCESS;
}

const char* MpAvatar::GetVersion()
{
    return motionportrait::MpRender::GetVersion();
}

/**
 * Resize viewport.
 *
 * \param w   screen width in pixels.
 * \param h   screen height in pixels.
 */
void MpAvatar::Resize(int w, int h) {

  if (!isInitialized_) {
    return;
  }

  screenW_ = w;
  screenH_ = h;

  if (zoom_) {
    viewportW_ = viewportH_ = (int) (screenW_ * 0.8f);
  } else {
    viewportW_ = viewportH_ = screenW_;
  }

  viewportX_ = (screenW_ - viewportW_) / 2;
  viewportY_ = (screenH_ - viewportH_) / 2;

  //
  // set viewport to MpRender
  //
  motionportrait::mpRect vp = {};
  vp.x = viewportX_;
  vp.y = viewportY_;
  vp.width = viewportW_;
  vp.height = viewportH_;
  render_->SetViewport(vp);
}

/**
 * Process touch event.
 *
 * \param x        X position on the screen in pixel.
 * \param y        Y position on the screen in pixel.
 * \param numTap   type of the action. acceptable values are
 *                 0=pressing, 1=released, or 2=double click/double tap.
 */
void MpAvatar::Touch(float x, float y, int numTap) {

  if (!isInitialized_) {
    return;
  }

  motionportrait::mpVector2 pos = {};

  switch (numTap) {
    case 0:
      // look at the touched direction.
      // the location in the screen coordinate system has to be converted
      // to the internal viewport coordinate system which has range 0.0 to 1.0.
      pos.x = (float) (x - viewportX_) / viewportW_;
      pos.y = (float) (screenH_ - y - viewportY_) / viewportH_;
      ctlAnim_->LookAt(0, pos, 1.0f);
      break;

    case 1:
      // front face
      pos.x = 0.5f;
      pos.y = 0.5f;
      ctlAnim_->LookAt(500, pos, 1.0f);
      break;

    case 2:
      // switch zoom mode
      zoom_ = !zoom_;

      if (zoom_) {
        viewportW_ = viewportH_ = (int) (screenW_ * 0.8f);
      } else {
        viewportW_ = viewportH_ = screenW_;
      }

      viewportX_ = (screenW_ - viewportW_) / 2;
      viewportY_ = (screenH_ - viewportH_) / 2;

      // set viewport to MpRender
      {
        motionportrait::mpRect vp = {};
        vp.x = viewportX_;
        vp.y = viewportY_;
        vp.width = viewportW_;
        vp.height = viewportH_;
        render_->SetViewport(vp);
      }
      break;
  }
}

/**
 * Set whether the background image is rendered.
 *
 * \param enable  set true if background image is rendered.
 */
void MpAvatar::DrawBackground(bool enable) {
  drawBackground_ = enable;
  render_->EnableDrawBackground(enable);
}

/**
 * Render avatar.
 */
void MpAvatar::Render() {

  glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
  glClear(GL_COLOR_BUFFER_BIT);

  if (!isInitialized_) {
    return;
  }

  //
  // handle queued event
  //
  handleEvent();

  if (!canRender_) {
    return;
  }

  long tm = getmsec();

  //
  // update unconscious animation
  //
  motionportrait::MpCtlAnimation *anim = face_->GetCtlAnimation();
  anim->Update(tm);

  if (anim_) {
    //
    // play animation file
    //
    int playing = ctlAnim_->AnimateData(animStartTime_, tm, anim_);

    if (playing == 0) {
      //
      // clean up after animation finish
      //
      ctlAnim_->DestroyAnimation(anim_);
      anim_ = 0;
      ctlAnim_->RestoreExprData();
      ctlAnim_->SetUnconsciousGain(1.0f);
    }
  }

  //
  // render
  //
  render_->Draw();
}

/**
 * Change face.
 *
 * \param facebinPath   path of the .bin file. (cannot be NULL)
 */
void MpAvatar::ChangeFace(const char *facebinPath) {
  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_CHANGE_FACE, facebinPath);
}

/**
 * Change hair.
 *
 * \param dataPath   path of the directory which contains data files. if NULL was passed
 *                   then deselect the current hair.
 */
void MpAvatar::ChangeHair(const char *dataPath) {
  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_CHANGE_HAIR, dataPath);
}

/**
 * Change beard.
 *
 * \param dataPath   path of the directory which contains data files. if NULL was passed
 *                   then deselect the current beard.
 */
void MpAvatar::ChangeBeard(const char *dataPath) {
  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_CHANGE_BEARD, dataPath);
}

/**
 * Change glasses.
 *
 * \param dataPath   path of the directory which contains data files. if NULL was passed
 *                   then deselect the current glasses.
 */
void MpAvatar::ChangeGlasses(const char *dataPath) {
  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_CHANGE_GLASSES, dataPath);
}

/**
 * Start predefined animation.
 *
 * \param dataPath        path of the ani file. if NULL was passed
 *                        then stop playing animation.
 * \param extraDataPath   path of the extra data file. (can be NULL if not needed)
 * \param soundFilePath   path of the sound file to play. (can be NULL if not needed)
 */
void MpAvatar::Animation(const char *dataPath,
                         const char *extraDataPath,
                         const char *soundFilePath) {
  stopSound();

  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_ANIMATION, dataPath, extraDataPath);

  playAnimSound(soundFilePath);
}

/**
 * Start speech.
 *
 * Note that voice data have to be set with PrepareSpeech() before call this method.
 */
void MpAvatar::Speech() {

  stopSound();

  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_SPEECH, NULL);

  playSpeechSound();
}

/**
 * Set voice data for speech.
 *
 * \param dataPath       path of the data file. if NULL was passed
 *                       then stop playing animation.
 * \param soundFilePath  path of the sound file to play. (can be NULL if not needed)
 */
void MpAvatar::PrepareSpeech(const char *dataPath, const char *soundFilePath) {

  stopSound();

  // execute in GL thread.
  queueEvent(MpAvatar::EVENT_PREPARE_SPEECH, dataPath);

  prepareSpeechSound(soundFilePath);
}

//--------------------------------------------------
// private methods
//--------------------------------------------------

/**
 * Append to the event queue.
 *
 * \param id    event id.
 * \param path  path information corresponding to the new event.
 */
void MpAvatar::queueEvent(eEvent id, const char *path) {
  queueEvent(id, path, NULL);
}

/**
 * Append to the event queue.
 *
 * \param id     event id.
 * \param path   path information corresponding to the new event.
 * \param path2  path information corresponding to the new event.
 */
void MpAvatar::queueEvent(eEvent id, const char *path, const char *path2) {

  const int nQueue = sizeof(eventQueue_) / sizeof(eEvent);

  eventQueueLock_.lock();

  if (nEvent_ < nQueue) {
    Event ev = { };
    ev.event = id;
    if (path != NULL) {
      char *pathCopy = new char[strlen(path) + 1];
      strcpy(pathCopy, path);
      ev.path = pathCopy;
    }
    if (path2 != NULL) {
      char *pathCopy = new char[strlen(path2) + 1];
      strcpy(pathCopy, path2);
      ev.path2 = pathCopy;
    }
    eventQueue_[nEvent_++] = ev;
  }

  eventQueueLock_.unlock();
}

/**
 * Process events in the event queue.
 */
void MpAvatar::handleEvent() {

  eventQueueLock_.lock();

  for (int i = 0; i < nEvent_; i++) {
    Event &ev = eventQueue_[i];

    switch (ev.event) {
      case EVENT_CHANGE_FACE:
        doChangeFace(ev.path);
        break;
      case EVENT_CHANGE_HAIR:
        doChangeHair(ev.path);
        break;
      case EVENT_CHANGE_BEARD:
        doChangeBeard(ev.path);
        break;
      case EVENT_CHANGE_GLASSES:
        doChangeGlasses(ev.path);
        break;
      case EVENT_ANIMATION:
        doAnimation(ev.path, ev.path2);
        break;
      case EVENT_PREPARE_SPEECH:
        doPrepareSpeech(ev.path);
        break;
      case EVENT_SPEECH:
        doSpeech();
        break;
      default:
        break;
    }

    delete[] ev.path;
    delete[] ev.path2;
    ev.path = ev.path2 = NULL;
  }
  nEvent_ = 0;

  eventQueueLock_.unlock();
}

/**
 * Change face (in GL thread)
 */
void MpAvatar::doChangeFace(const char *dataPath) {
  loadFace(dataPath);
}

/**
 * Change hair (in GL thread)
 */
void MpAvatar::doChangeHair(const char *dataPath) {
  loadItem(dataPath, ctlHair_, &hair_);
}

/**
 * Change beard (in GL thread)
 */
void MpAvatar::doChangeBeard(const char *dataPath) {
  loadItem(dataPath, ctlBeard_, &beard_);
}

/**
 * Change glasses (in GL thread)
 */
void MpAvatar::doChangeGlasses(const char *dataPath) {
  loadItem(dataPath, ctlGlasses_, &glasses_);
}

/**
 * Set voice data for speech. (in GL thread)
 */
void MpAvatar::doPrepareSpeech(const char *dataPath) {
  //
  // clean up previous voice
  //
  ctlSpeech_->SpeakStop();
  if (voice_) {
    ctlSpeech_->DestroyVoice(voice_);
    voice_ = 0;
  }

  //
  // create voice
  //
  voice_ = ctlSpeech_->CreateVoice(const_cast<char*>(dataPath));

  if (voice_ == 0) {
    qWarning("Failed to load voice: %s", dataPath);
  }
}

/**
 * Start speech. (in GL thread)
 */
void MpAvatar::doSpeech() {

  if (voice_ == 0) {
    qWarning("voice is not prepared yet.");
    return;
  }

  //
  // clean up previous animation
  //
  doCancelAnimation();

  // set lip sync gain
  ctlSpeech_->SetGain(0.6f);

  //
  // start lip sync
  //
  ctlSpeech_->Speak(voice_);
}

/**
 * Start predefined animation. (in GL thread)
 */
void MpAvatar::doAnimation(const char *dataPath, const char *extraDataPath) {
  //
  // clean up previous animation
  //
  doCancelAnimation();

  if (dataPath == NULL) {
    return;
  }

  //
  // create animation
  //
  anim_ = ctlAnim_->CreateAnimation(const_cast<char*>(dataPath));
  if (anim_ == 0) {
    qWarning("Failed to load animation: %s", dataPath);
    return;
  }

  // save current time as animation start time
  animStartTime_ = getmsec();

  //
  // load customized expression for animation
  //
  if (extraDataPath != NULL) {
    ctlAnim_->SetExprData(const_cast<char*>(extraDataPath));
  }

  //
  // disable unconscious animation
  //
  ctlAnim_->SetUnconsciousGain(0.0f);
}

/**
 * Stop playing animation.
 */
void MpAvatar::doCancelAnimation() {
  if (anim_) {
    ctlAnim_->DestroyAnimation(anim_);
    ctlAnim_->RestoreExprData();
    ctlAnim_->SetUnconsciousGain(1.0f);
    anim_ = 0;
  }
}

/**
 * Load face data.
 *
 * \param path   path of the .bin file.
 *
 * \return  MP_SUCCESS if loading data succeeded. otherwise an error code is returned.
 */
int MpAvatar::loadFace(const char *path) {
  //
  // close items
  //
  if (hair_) {
    ctlHair_->Destroy(hair_);
    hair_ = 0;
  }
  if (beard_) {
    ctlBeard_->Destroy(beard_);
    beard_ = 0;
  }
  if (glasses_) {
    ctlGlasses_->Destroy(glasses_);
    glasses_ = 0;
  }

  //
  // load face
  //
  motionportrait::mpResult ret = face_->Load(path);
  if (ret != MP_SUCCESS) {
    qWarning("Failed to load specified face model.");
    return ret;
  }

  //
  // set face to renderer
  //
  render_->SetFace(face_);

  // set neck rotation parameters
  ctlAnim_->SetParamf(motionportrait::MpCtlAnimation::NECK_X_MAX_ROT, 2.0f);
  ctlAnim_->SetParamf(motionportrait::MpCtlAnimation::NECK_Y_MAX_ROT, 2.0f);
  ctlAnim_->SetParamf(motionportrait::MpCtlAnimation::NECK_Z_MAX_ROT, 0.3f);

  canRender_ = true;

  return MP_SUCCESS;
}

/**
 * Load item data.
 *
 * \param path   path of the data file or path of the directory which contains data files.
 * \param ctl    pointer to a control object corresponding to the item type.
 * \param item   pointer to a variable. item id is set if loading item succeeded.
 *
 * \return  MP_SUCCESS if loading item succeeded. otherwise an error code is returned.
 */
int MpAvatar::loadItem(const char *path, motionportrait::MpCtlItem *ctl, long *item) {
  //
  // clean up previous item
  //
  if (*item) {
    ctl->UnsetItem(*item);
    ctl->Destroy(*item);
    *item = 0;
  }

  if (path == NULL) {
    return MP_SUCCESS;
  }

  //
  // create item
  //
  *item = ctl->Create(const_cast<char*>(path));
  if (*item == 0) {
    qWarning("Failed to load item: %s", path);
    return -1;
  }

  //
  // bind item to avatar
  //
  ctl->SetItem(*item);

  return MP_SUCCESS;
}

/**
 * Stop sound
 */
void MpAvatar::stopSound() {
#ifdef USE_QMEDIAPLAYER
  mediaPlayer_.stop();
#else
  if (soundVoice_) {
    soundVoice_->stop();
  }
  if (soundAnim_) {
    soundAnim_->stop();
  }
#endif
}

/**
 * Prepare sound settings for speech
 */
void MpAvatar::prepareSpeechSound(const char *soundFilePath) {
#ifdef USE_QMEDIAPLAYER
  if (soundFilePath != NULL) {
    mediaContentSpeech_ = QMediaContent(QUrl::fromLocalFile(soundFilePath));
  } else {
    mediaContentSpeech_ = QMediaContent();
  }
#else
  delete soundVoice_;
  soundVoice_ = NULL;
  if (soundFilePath != NULL) {
    soundVoice_ = new QSound(soundFilePath);
  }
#endif
}

/**
 * Play sound for speech
 */
void MpAvatar::playSpeechSound() {
#ifdef USE_QMEDIAPLAYER
  mediaPlayer_.setMedia(mediaContentSpeech_);
  mediaPlayer_.play();
#else
  if (soundVoice_) {
      soundVoice_->play();
  }
#endif
}

/**
 * Play sound for animation
 */
void MpAvatar::playAnimSound(const char *soundFilePath) {
#ifdef USE_QMEDIAPLAYER
  if (soundFilePath != NULL) {
    mediaPlayer_.setMedia(QUrl::fromLocalFile(soundFilePath));
    mediaPlayer_.play();
  } else {
    mediaPlayer_.setMedia(QMediaContent());
  }
#else
  delete soundAnim_;
  soundAnim_ = new QSound(soundFilePath);
  soundAnim_->play();
#endif
}

/**
 * Cleanup sound objects
 */
void MpAvatar::cleanupSound() {
  stopSound();
#ifdef USE_QMEDIAPLAYER
  // This is workaround for the issue that exception occurs
  // at deleting QMediaPlayer, when it is paused or stoped.
  if(mediaPlayer_.state() != QMediaPlayer::PlayingState) {
    mediaPlayer_.play();
  }
  mediaPlayer_.setMedia(NULL);
#else
  delete soundVoice_;
  delete soundAnim_;
#endif
}
