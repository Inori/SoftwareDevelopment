#!/bin/sh

rm -rf debug release

qmake CONFIG-=debug CONFIG-=release CONFIG+=debug_and_release mpavatar.pro && make $*

