/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#ifndef MPGLVIEW_H
#define MPGLVIEW_H

#include <QGLWidget>

class MpAvatar;
class QBasicTimer;

/**
 * Custom OpenGL widget for rendering avatar and handling some events.
 */
class MpGLView : public QGLWidget {

  Q_OBJECT

 public:
  explicit MpGLView(QWidget *parent = 0, const char *name = 0);
  ~MpGLView();

  void Initialize(MpAvatar *);
  void Terminate();

  Q_SLOT
  void onScreenChanged(QScreen * screen);

 protected:
  // overrides QGLWidget
  virtual void initializeGL();
  virtual void resizeGL(int width, int height);
  virtual void paintGL();
  // overrides QWidget
  virtual void mousePressEvent(QMouseEvent *event);
  virtual void mouseReleaseEvent(QMouseEvent *event);
  virtual void mouseMoveEvent(QMouseEvent *event);
  virtual void mouseDoubleClickEvent(QMouseEvent *event);
  // overrides QObject
  virtual void timerEvent(QTimerEvent *event);

 private:
  MpAvatar *mpAvatar_;
  QBasicTimer *repaintTimer_;
  bool canRender_;
};

#endif // MPGL_H
