/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <memory>
#include <list>
#include <QMainWindow>
#include <QDir>
#include <QString>
#include <QSharedPointer>

// from ui_mainwindow.h
namespace Ui {
class MainWindow;
}  // namespace Ui

class MpAvatar;
class MpGLView;
class QTemporaryDir;

/**
 * Main window
 */
class MainWindow : public QMainWindow {
  Q_OBJECT

 public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();

  void Initialize();

private:
  typedef QSharedPointer<QTemporaryDir> TemporaryDirSPtr;

public Q_SLOTS:
  void selectFace_currentIndexChanged(int index);
  void selectHair_currentIndexChanged(int index);
  void selectBeard_currentIndexChanged(int index);
  void selectGlasses_currentIndexChanged(int index);
  void selectVoice_currentIndexChanged(int index);
  void selectAnimation_currentIndexChanged(int index);
  void buttonSpeech_clicked(bool checked);
  void actionShowBackground_toggled(bool checked);
  void buttonCreate_clicked(bool checked);
  void onGererateAvatarFinished(bool result, const QString faceFile, const QString avatarFile);

signals:
  void generateAvatarFinished(bool result, const QString faceFile, const QString avatarFile);

 private:
  Ui::MainWindow *ui_;
  MpGLView *mpGLView_;
  MpAvatar *mpAvatar_;
  QDir resourcePathBase_;
  std::list<TemporaryDirSPtr> avatarDirectories_;

  void generateAvatar(const QString& faceFile);
};

#endif // MAINWINDOW_H
