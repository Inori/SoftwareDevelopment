/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#include <algorithm>

#include <QResizeEvent>

#include "squareviewcontainer.h"
#include "mpglview.h"

/**
 * Constructor
 */
SquareViewContainer::SquareViewContainer(QWidget* parent, Qt::WindowFlags f)
    : QWidget(parent, f) {
}

/**
 * Destructor
 */
SquareViewContainer::~SquareViewContainer() {
}

/**
 * Overrides QWidget event handler
 */
void SquareViewContainer::resizeEvent(QResizeEvent *event) {

  QWidget::resizeEvent(event);

  static const int MIN_GLVIEW_SIZE = 10;

  // determine size of the child widget
  int w, h;
  w = h = (std::max)(
            (std::min)(event->size().width(), event->size().height()),
            MIN_GLVIEW_SIZE);

  // apply to children
  for (QObjectList::ConstIterator iter = children().begin();
      iter != children().end();
      ++iter) {

    QWidget *widget = reinterpret_cast<QWidget*>(*iter);
    widget->resize(w, h);
  }
}

