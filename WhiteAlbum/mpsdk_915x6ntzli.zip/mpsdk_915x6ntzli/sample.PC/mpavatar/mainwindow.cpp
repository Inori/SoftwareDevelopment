/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#include <QtDebug>
#include <QFileDialog>
#include <QMovie>
#include <QTemporaryDir>
#include <QtConcurrent/QtConcurrent>
#include <QFile>
#include <QWindow>
#include <QMessageBox>
#include "ui_mainwindow.h"
#include "createavatar.h"

#include "mainwindow.h"
#include "mpglview.h"
#include "mpavatar.h"

//! Created avatar file name
#define NAME_YOUR_AVATAR "youravatar.bin"

//------------------------------------------------------------
// forward declarations
//------------------------------------------------------------
static void setSelectorEntries(QComboBox *selector, const QDir &dir, bool isDir,
                               const QString &extension, bool addNone);
static QString getPathFromSelector(QComboBox *selector, int index);

//------------------------------------------------------------
// macro
//------------------------------------------------------------

#define cstr(S) (S.toLocal8Bit().constData())
#define cstrOrNull(S) (S.isNull() ? NULL : S.toLocal8Bit().constData())

//------------------------------------------------------------
// MainWindow implementations
//------------------------------------------------------------

/**
 * Constructor.
 */
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      ui_(NULL),
      mpGLView_(NULL),
      mpAvatar_(NULL),
      resourcePathBase_() {

  ui_ = new Ui::MainWindow();
  ui_->setupUi(this);

  resourcePathBase_ = QDir(QCoreApplication::applicationDirPath());
}

/**
 * Destructor.
 */
MainWindow::~MainWindow() {
  if (mpGLView_) {
    mpGLView_->Terminate();
  }
  delete mpAvatar_;
  delete ui_;

  qDebug("MainWindow destroyed");
}

/**
 * Initialize main window.
 */
void MainWindow::Initialize() {

  // search items from the resource directory
  // and add entries to the selectors.

  // faces
  setSelectorEntries(ui_->selectFace,
                     QDir(resourcePathBase_.filePath("face")),
                     false, ".bin", false);
  // hairs
  setSelectorEntries(ui_->selectHair,
                     QDir(resourcePathBase_.filePath("hair")),
                     true, "", true);
  // beards
  setSelectorEntries(ui_->selectBeard,
                     QDir(resourcePathBase_.filePath("beard")),
                     true, "", true);
  // glasses
  setSelectorEntries(ui_->selectGlasses,
                     QDir(resourcePathBase_.filePath("glasses")),
                     true, "", true);
  // voices
  setSelectorEntries(ui_->selectVoice,
                     QDir(resourcePathBase_.filePath("voice")),
                     false, ".env;.wav", true);
  // animations
  setSelectorEntries(ui_->selectAnimation,
                     QDir(resourcePathBase_.filePath("anim")),
                     true, "", true);

  // set toggle menu state
  ui_->actionShowBackground->setChecked(false);

  // set event handlers

  QObject::connect(ui_->selectFace,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectFace_currentIndexChanged(int)));

  QObject::connect(ui_->selectHair,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectHair_currentIndexChanged(int)));

  QObject::connect(ui_->selectBeard,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectBeard_currentIndexChanged(int)));

  QObject::connect(ui_->selectGlasses,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectGlasses_currentIndexChanged(int)));

  QObject::connect(ui_->selectVoice,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectVoice_currentIndexChanged(int)));

  QObject::connect(ui_->selectAnimation,
                   SIGNAL(currentIndexChanged(int)),
                   this,
                   SLOT(selectAnimation_currentIndexChanged(int)));

  QObject::connect(ui_->buttonSpeech,
                   SIGNAL(clicked(bool)),
                   this,
                   SLOT(buttonSpeech_clicked(bool)));

  QObject::connect(ui_->actionShowBackground,
                   SIGNAL(toggled(bool)),
                   this,
                   SLOT(actionShowBackground_toggled(bool)));

  QObject::connect(ui_->buttonCreate,
                   SIGNAL(clicked(bool)),
                   this,
                   SLOT(buttonCreate_clicked(bool)));

  QObject::connect(this,
                   SIGNAL(generateAvatarFinished(bool, const QString, const QString)),
                   SLOT(onGererateAvatarFinished(bool, const QString, const QString)));

  // create avatar object
  mpAvatar_ = new MpAvatar();

  // set version number as window title
  QString title("MotionPortrait Demo ");
  this->setWindowTitle(title + mpAvatar_->GetVersion());

  // initialize avatar
  QString comparts = resourcePathBase_.filePath("comparts");
  mpAvatar_->Initialize(cstr(comparts));

  // create child widget which renders the avatar
  mpGLView_ = new MpGLView(ui_->widgetView);
  mpGLView_->move(0, 0);

  // set avatar to the child widget
  mpGLView_->Initialize(mpAvatar_);

  QObject::connect(windowHandle(),
                   SIGNAL(screenChanged(QScreen *)),
                   mpGLView_,
                   SLOT(onScreenChanged(QScreen *)));

  // Circular progress bar
  QMovie* spinner = new QMovie(":/icon/spinner.gif");
  ui_->labelSpinner->setMovie(spinner);
  ui_->labelSpinner->hide();
  spinner->start();

  // load initial face
  QString faceDataPath = getPathFromSelector(ui_->selectFace, 0);
  if (!faceDataPath.isNull()) {
    mpAvatar_->ChangeFace(cstr(faceDataPath));
  }
}

/**
 * event handler: another face has been chosen.
 */
void MainWindow::selectFace_currentIndexChanged(int index) {

  QString path = getPathFromSelector(ui_->selectFace, index);

  qDebug("select face : %s", cstr(path));

  if (!path.isNull()) {
    mpAvatar_->ChangeFace(cstr(path));

    ui_->selectHair->setCurrentIndex(0);
    ui_->selectBeard->setCurrentIndex(0);
    ui_->selectGlasses->setCurrentIndex(0);
    ui_->selectVoice->setCurrentIndex(0);
    ui_->selectAnimation->setCurrentIndex(0);
  }
}

/**
 * event handler: another hair has been chosen.
 */
void MainWindow::selectHair_currentIndexChanged(int index) {

  QString path = getPathFromSelector(ui_->selectHair, index);

  qDebug("select hair : %s", cstr(path));

  mpAvatar_->ChangeHair(cstrOrNull(path));
}

/**
 * event handler: another beard has been chosen.
 */
void MainWindow::selectBeard_currentIndexChanged(int index) {

  QString path = getPathFromSelector(ui_->selectBeard, index);

  qDebug("select beard : %s", cstr(path));

  mpAvatar_->ChangeBeard(cstrOrNull(path));
}

/**
 * event handler: other glasses have been chosen.
 */
void MainWindow::selectGlasses_currentIndexChanged(int index) {

  QString path = getPathFromSelector(ui_->selectGlasses, index);

  qDebug("select glasses : %s", cstr(path));

  mpAvatar_->ChangeGlasses(cstrOrNull(path));
}

/**
 * event handler: another voice has been chosen.
 */
void MainWindow::selectVoice_currentIndexChanged(int index) {

  QString dataPath = getPathFromSelector(ui_->selectVoice, index);

  qDebug("select voice : %s", cstr(dataPath));

  if (dataPath.isNull()) {
    return;
  }

  // determine sound file
  QString soundFilePath;
  QString ext = dataPath.right(4).toLower();
  if (ext.endsWith(".env")) {
    soundFilePath = dataPath.left(dataPath.length() - 4) + ".mp3";
  } else if (ext.endsWith(".wav")) {
    soundFilePath = dataPath;
  }

  qDebug("       sound : %s", cstr(soundFilePath));

  mpAvatar_->PrepareSpeech(cstrOrNull(dataPath), cstrOrNull(soundFilePath));
  mpAvatar_->Speech();
}

/**
 * event handler: another animation has been chosen.
 */
void MainWindow::selectAnimation_currentIndexChanged(int index) {

  QString dataDirPath = getPathFromSelector(ui_->selectAnimation, index);

  qDebug("select animation : %s", cstr(dataDirPath));

  if (dataDirPath.isNull()) {
    return;
  }

  // determine data files
  QDir dataDir(dataDirPath);

  QString aniFilePath = dataDir.filePath("anim.ani2");
  QString extraDataPath = dataDir.filePath("anim.txt");
  QString soundFilePath = dataDir.filePath("anim.mp3");

  if (!QFileInfo(aniFilePath).exists()) {
    return;
  }
  if (!QFileInfo(extraDataPath).exists()) {
    extraDataPath = QString();
  }
  if (!QFileInfo(soundFilePath).exists()) {
    soundFilePath = QString();
  }

  qDebug("            data : %s", cstr(aniFilePath));
  qDebug("           extra : %s", cstr(extraDataPath));
  qDebug("           sound : %s", cstr(soundFilePath));

  mpAvatar_->Animation(cstrOrNull(aniFilePath),
                       cstrOrNull(extraDataPath),
                       cstrOrNull(soundFilePath));
}

/**
 * event handler: speech button has been clicked.
 */
void MainWindow::buttonSpeech_clicked(bool checked) {

  Q_UNUSED(checked)

  mpAvatar_->Speech();
}

/**
 * event handler: 'show background' option has been toggled.
 */
void MainWindow::actionShowBackground_toggled(bool checked) {
  mpAvatar_->DrawBackground(checked);
}

/**
 * event handler: create button has been clicked.
 */
void MainWindow::buttonCreate_clicked(bool checked) {

  Q_UNUSED(checked)

  QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"), 0,tr("Images (*.jpg *.jpeg *.png)", 0, QFileDialog::ReadOnly));
  if (fileName.isEmpty()) {
      qDebug() << "MainWindow::buttonCreate_clicked : canceled";
      return;
  }
  ui_->labelSpinner->show();
  qDebug() << "MainWindow::buttonCreate_clicked : file name = " << fileName;
  QtConcurrent::run(this, &MainWindow::generateAvatar, fileName);
}

/**
 * @brief Generates a new avatar with ¥a faceFile.
 * @param faceFile Face image file.
 */
void MainWindow::generateAvatar(const QString &faceFile)
{
    bool result = false;
    QString yourAvatar;
    try {
        TemporaryDirSPtr tmpAvatarDir(new QTemporaryDir());
        tmpAvatarDir->setAutoRemove(true);
        QString fnameFormat = "%1%2%3";
        yourAvatar = fnameFormat.arg(tmpAvatarDir->path(), QDir::separator(), NAME_YOUR_AVATAR);
        qDebug() << "MainWindow::generateAvatar: faceFile=" << faceFile << ", avatar file=" << yourAvatar;
        result = CreateAvatar::Create(faceFile, yourAvatar);
        if (result) {
            avatarDirectories_.push_back(tmpAvatarDir); // Reserves the avatar directory. This will be removed when the list avatarDirectories_ is cleared.
        } else {
            qWarning() << "MainWindow::generateAvatar: failed. faceFile=" << faceFile;
        }
    } catch(...) {
        qCritical() << "MainWindow::generateAvatar: exception raised. faceFile=" << faceFile;
        result = false;
    }

    emit  generateAvatarFinished(result, faceFile, yourAvatar);
}

/**
 * @brief Callback to notify a completion of the avatar generation.
 * @param result True if the avatar generation has succeeded. Otherwide, false.
 * @param faceFile Face image file used to create the avatar.
 * @param avatarFile Avatar file
 */
void MainWindow::onGererateAvatarFinished(bool result, const QString faceFile, const QString avatarFile)
{
    qDebug() << "MainWindow::onGererateAvatorFinished: " << (result ? "succeeded" : "failed");
    if (result) {
        QFileInfo finfo(faceFile);
        QComboBox* selector = ui_->selectFace;
        selector->addItem(finfo.fileName()/*excluding directory path*/, QVariant(avatarFile));
        selector->setCurrentIndex(selector->count() - 1);
    } else {
        QMessageBox::critical(this, "Error", "Failed to create an avatar");
    }
    ui_->labelSpinner->hide();
}


//------------------------------------------------------------
// Static functions
//------------------------------------------------------------

/**
 * Search entries from the specified directory, then add them to the selector.
 *
 * \param selector   widget the new items are added to
 * \param dir        directory to search
 * \param isDir      whether the entry is a sub-directory in dir
 * \param extensions extension part of the file name (includes dot, separated by semicolon)
 * \param addNone    whether the empty entry is added first
 */
static void setSelectorEntries(
    QComboBox *selector,
    const QDir &dir,
    bool isDir,
    const QString &extensions,
    bool addNone
    ) {

  selector->clear();

  if (addNone) {
    selector->addItem("", QStringList());
  }

  QStringList nameFilters;
  if (!extensions.isEmpty()) {
    QStringList exts = extensions.split(';');
    for (QStringList::ConstIterator iter = exts.begin();
        iter != exts.end();
        ++iter) {

      nameFilters << ("*" + *iter);
    }
  }
  QDir::Filters filters =
      isDir ? (QDir::Dirs | QDir::NoDotAndDotDot) : QDir::Files;

  const QFileInfoList &list =
      dir.entryInfoList(nameFilters, filters, QDir::Name);

  for (QFileInfoList::ConstIterator iter = list.begin();
      iter != list.end();
      ++iter) {

    QString fullPath = iter->filePath();
    QString name = iter->fileName();

    if (!extensions.isEmpty()) {
      // remove extension
      int p = name.lastIndexOf('.');
      if (p >= 0) {
        name = name.left(p);
      }
    }

    selector->addItem(name, QVariant(fullPath));
  }
}

/**
 * Get path string corresponding to the specified list item.
 *
 * \param selector  selector widget
 * \param index     index of the list item
 *
 * \return  path string. Null QString is returned if a string data is not provided by the list item.
 */
static QString getPathFromSelector(QComboBox *selector, int index) {

  QVariant data = selector->itemData(index);
  if (data.type() != QVariant::String) {
    return QString();  // equivalent to null
  }
  return data.toString();
}
