/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#include <QBasicTimer>
#include <QMouseEvent>
#include <QWindow>
#include <QtDebug>
#include <cmath>
#include "mpglview.h"
#include "mpavatar.h"

//------------------------------------------------------------
// Constant values
//------------------------------------------------------------

// background color to fill
static const float BG_R = 128 / 255.0f;
static const float BG_G = 128 / 255.0f;
static const float BG_B = 128 / 255.0f;

// frame rate
static const float FPS = 20.0f;

//------------------------------------------------------------
// MpGLView implementations
//------------------------------------------------------------

/**
 * Constructor
 */
MpGLView::MpGLView(QWidget *parent, const char *name)
    : QGLWidget(parent),
      mpAvatar_(NULL),
      repaintTimer_(NULL),
      canRender_(false) {

  Q_UNUSED(name);

  repaintTimer_ = new QBasicTimer();
}

/**
 * Destructor
 */
MpGLView::~MpGLView() {
  delete repaintTimer_;
  qDebug("MpGLView destroyed");
}

/**
 * Initialize with avatar.
 *
 * \param avatar  avatar to render.
 */
void MpGLView::Initialize(MpAvatar *avatar) {
  mpAvatar_ = avatar;

  canRender_ = true;
  repaintTimer_->start(static_cast<int>(1000 / FPS), this);
}

/**
 * Stop rendering.
 */
void MpGLView::Terminate() {
  canRender_ = false;
  if (repaintTimer_ && repaintTimer_->isActive()) {
    repaintTimer_->stop();
  }
  qDebug("MpGLView terminated");
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::initializeGL() {

  QGLWidget::initializeGL();

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glClearColor(BG_R, BG_G, BG_B, 1.0f);
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::resizeGL(int width, int height) {
  qreal ratio = windowHandle()->devicePixelRatio();
  qDebug() << "devicePixelRatio = " << ratio;
  qDebug() << "MpGLView::resizeGL(" << width << ", " << height << ")";
  QGLWidget::resizeGL(width, height);

  if (mpAvatar_) {
    mpAvatar_->Resize(width, height);
  }
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::paintGL() {

  QGLWidget::paintGL();

  if (canRender_ && mpAvatar_) {
    mpAvatar_->Render();
  }
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::mousePressEvent(QMouseEvent *event) {

  QGLWidget::mousePressEvent(event);

  if (event->button() == Qt::LeftButton) {
    if (mpAvatar_) {
      qreal ratio = this->windowHandle()->devicePixelRatio();
      // Note that MpAvatar::Touch() requires the current physical position.
      mpAvatar_->Touch(event->x() * ratio, event->y() * ratio, 0);
    }
  }
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::mouseReleaseEvent(QMouseEvent *event) {

  QGLWidget::mouseReleaseEvent(event);

  if (event->button() == Qt::LeftButton) {
    if (mpAvatar_) {
      qreal ratio = this->windowHandle()->devicePixelRatio();
      // Note that MpAvatar::Touch() requires the current physical position.
      mpAvatar_->Touch(event->x() * ratio, event->y() * ratio, 1);
    }
  }
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::mouseMoveEvent(QMouseEvent *event) {

  QGLWidget::mouseMoveEvent(event);

  if (event->buttons() & Qt::LeftButton) {
    if (mpAvatar_) {
        qreal ratio = this->windowHandle()->devicePixelRatio();
        // Note that MpAvatar::Touch() requires the current physical position.
        mpAvatar_->Touch(event->x() * ratio, event->y() * ratio, 0);
    }
  }
}

/**
 * Overrides QGLWidget event handler
 */
void MpGLView::mouseDoubleClickEvent(QMouseEvent *event) {

  QGLWidget::mouseDoubleClickEvent(event);

  if (event->button() == Qt::LeftButton) {
    if (mpAvatar_) {
      mpAvatar_->Touch(event->x(), event->y(), 2);
    }
  }
}

/**
 * Overrides timer event handler
 */
void MpGLView::timerEvent(QTimerEvent *event) {

  QGLWidget::timerEvent(event);

  updateGL();
}

/**
 * @brief Slot to receive screenChanged signals. The avatar needs to be resized if the device pixel ratio has been chaned.
 *
 * @param screen
 */
void MpGLView::onScreenChanged(QScreen * screen)
{
    qDebug() << "Screen changed. Device pixel ratio = " << this->devicePixelRatio();
    if (mpAvatar_) {
        qDebug() << "Size = " << width() << "x" << height();
        qreal ratio = windowHandle()->devicePixelRatio();
        int w = (int)round(width() * ratio);
        int h = (int)round(height() * ratio);
        mpAvatar_->Resize(w, h);
    }
}
