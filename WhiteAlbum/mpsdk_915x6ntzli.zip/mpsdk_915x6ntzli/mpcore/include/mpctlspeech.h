/*
 *
 * Copyright 2013-2014 by MotionPortrait, Inc.
 *
 * All rights reserved.
 *
 */

#ifndef MPCTLSPEECH_H_
#define MPCTLSPEECH_H_

#include "mptypes.h"

namespace motionportrait {


class MpCtlSpeechImpl;

/**
 * \class MpCtlSpeech
 *
 * MpCtlSpeech class controls lip synch of an avatar
 */
class MpCtlSpeech {

  public:

    /** voice data id */
    typedef long VoiceId;

    /**
     * create voice data
     *
     * @param pathVoice : path to voice file.
     *                   voice file must be WAV or ENV format.
     *                   ENV file can be converted from WAV by MPAnavoice tool.
     * @return voice data id
     */
    VoiceId CreateVoice(char *pathVoice);

    /**
     * voice buffer data structure
     */
    typedef struct {
        int nChannel;           /**< number of channel */
        int bytesPerSample;     /**< bytes per sample */
        int sampleRate;         /**< samples per second */
        int nbyte;              /**< byte size of the buffer */
        void *buffer;           /**< buffer data */
    } VoiceBufferData;

    /**
     * create voice data from buffer
     *
     * @param  data : voice buffer data
     * @return voice data id
     */
    VoiceId CreateVoice(VoiceBufferData &data);

    /**
     * destroy voice data
     *
     * @param voice : voice data id
     */
    mpResult DestroyVoice(VoiceId voice);

    /**
     * start lip sync
     *
     * @param voice : voice data id
     */
    mpResult Speak(VoiceId voice);

    /**
     * stop lip sync
     */
    mpResult SpeakStop();

    /**
     * resume lip sync
     */
    mpResult SpeakResume();

    /**
     * set lip sync gain value
     *
     * @param gain : lip sync gain as [0.0, 1.0]
     */
    mpResult SetGain(float gain);

    /**
     * get lip sync gain value
     *
     * @return current lip sync gain value
     */
    float GetGain();

    /**
     * get voice duration
     *
     * @return voice duration in milli second
     */
    float GetDuration(VoiceId voice);

    /**
     * data structure for realtime lip sync set up
     */
    typedef struct {
        int bytesPerSample;     /**< bytes per sample */
        int sampleRate;         /**< samples per second */
    } RtSpeakInfo;

    /**
     * start realtime lip sync
     *
     * @param info : real time lip sync information
     */
    mpResult RtSpeakStart(RtSpeakInfo *info);

    /**
     * stop realtime lip sync
     */
    mpResult RtSpeakStop();

    /**
     * queue realtime lip sync buffer
     *
     * @param buffer : buffer of voice data.
                       The data must be PCM linear format with
                       sample rate specified by RtSpeakStart()
     * @param nbyte  : byte size of the buffer
     */
    mpResult RtSpeakQueue(void *buffer, int nbyte);

    /**
     * set realtime lip sync gain
     *
     * @param gain : realtime lip sync gain as [0.0, 1.0]
     */
    mpResult RtSpeakGain(float gain);

    /**
     */
    MpCtlSpeech();
    virtual ~MpCtlSpeech();

    MpCtlSpeechImpl *mp_;
};


} // namespace motionportrait

#endif /* MPCTLSPEECH_H_ */
