/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#include <memory>
#include "createavatar.h"
#include <QtDebug>
#include <QDir>
#include <QtCore>
#include <QImage>
#include <QScopedArrayPointer>
#include "mpsynth.h"

using namespace motionportrait;

/**
 * @brief Creates a new avatar
 * @param faceFile Face image file to create an avatar.
 * @param pathRes Path to the result directory.
 * @return True if the avatar generation has succeeded. Otherwide, false.
 */
bool CreateAvatar::Create(const QString& faceFile, const QString& pathRes)
{
    // Loading the image file
    QImage image;
    bool loaded = image.load(faceFile);
    if (!loaded) {
        qWarning() << "CreateAvatar::Create: failed to load " << faceFile;
        return false;
    }
    QImage::Format format = image.format();
    if (format != QImage::Format_RGB888) {
        image = image.convertToFormat(QImage::Format_RGB888);
    }
    int bytesPerLine = image.bytesPerLine();
    int bytesCount = image.byteCount();
    qDebug() << "Image: " << image.width() << "x" << image.height() << ", scanLineSize=" << bytesPerLine << "bytes, total size=" << bytesCount << "bytes";
    uchar* imagePtr;
    QScopedArrayPointer<uchar> imageData;
    const int bytesPerLineRequired = image.width() * 3;
    if (bytesPerLine == bytesPerLineRequired) {
        imagePtr = image.bits();
    } else { // each line has some paddings. Creates a new image buffer without padding.
        imageData.reset(new uchar[bytesPerLineRequired * image.height()]);
        for (int y = 0; y < image.height(); y++) {
            const uchar* psrc = image.scanLine(y);
            uchar* pdst = imageData.data() + bytesPerLineRequired * y;
            memcpy(pdst, psrc, bytesPerLineRequired);
        }
        imagePtr = imageData.data();
    }

    MpSynth synth;
    //
    // initialize Synthesizer
    //
    QDir resourcePathBase = QDir(QCoreApplication::applicationDirPath());
    int stat = synth.Init(resourcePathBase.filePath("res").toLocal8Bit().data());
    if(stat) {
        //[messageBox showMessage:@"Cannot initialize recogintion machine." title:@"Internal error"];
        return false;
    }

    synth.SetParami(MpSynth::OUTPUT_FORMAT, MpSynth::FORMAT_BIN) ;
    synth.SetParami(MpSynth::TEX_SIZE, 512) ;
    synth.SetParami(MpSynth::MODEL_SIZE, 256) ;
    synth.SetParamf(MpSynth::FACE_SIZE, 0.6) ;
    synth.SetParamf(MpSynth::FACE_POS, 0.5) ;
    synth.SetParami(MpSynth::CROP_MARGIN, 1);

    MpSynth::Img inImg;
    inImg.w = image.width();
    inImg.h = image.height();
    inImg.rgb = imagePtr;
    inImg.alpha = NULL;

    //
    // synthesize
    //
    stat = synth.Synth(inImg, pathRes.toLocal8Bit().data());
    if (stat == 0) {
        qDebug("CreateAvatar::Create: done");
        return true;
    } else {
        qWarning("CreateAvatar::Create: synthesize failed");
        return false;
    }
}
