/*
 Copyright(C) 2013-2014 MotionPortrait, Inc. All Rights Reserved.

 This software is provided 'as-is', without any express or implied
 warranty. In no event will the authors be held liable for any damages
 arising from the use of this software.

 Permission is granted to anyone to use this software for any purpose,
 including commercial applications, and to alter it and redistribute it.
 */

#ifndef MP_AVATAR_H
#define MP_AVATAR_H

#include <QtGlobal>
#if QT_VERSION >= 0x050000
#define USE_QMEDIAPLAYER
#endif

#ifdef USE_QMEDIAPLAYER
#include <QMediaPlayer>
#else
#include <QSound>
#endif

#include <QMutex>

#include "mptypes.h"

namespace motionportrait {
class MpRender;
class MpFace;
class MpCtlItem;
class MpCtlSpeech;
class MpCtlAnimation;
}

/**
 * Manage MpRender and MpFace.
 */
class MpAvatar {

 public:
  MpAvatar();
  ~MpAvatar();

  // public methods
  int Initialize(const char *compartsPath);
  const char* GetVersion();
  void Resize(int w, int h);
  void Touch(float x, float y, int numTap);
  void Render();

  void DrawBackground(bool enable);

  void ChangeFace(const char *dataPath);
  void ChangeHair(const char *dataPath);
  void ChangeBeard(const char *dataPath);
  void ChangeGlasses(const char *dataPath);
  void Animation(const char *dataPath,
                 const char *extraDataPath,
                 const char *soundFilePath);
  void CancelAnimation();
  void PrepareSpeech(const char *dataPath, const char *soundFilePath);
  void Speech();

 private:
  bool isInitialized_;
  bool canRender_;

  // MP instance
  motionportrait::MpRender *render_;
  motionportrait::MpFace *face_;

  // MP controller
  motionportrait::MpCtlSpeech *ctlSpeech_;
  motionportrait::MpCtlAnimation *ctlAnim_;
  motionportrait::MpCtlItem *ctlHair_;
  motionportrait::MpCtlItem *ctlBeard_;
  motionportrait::MpCtlItem *ctlGlasses_;

  // item IDs
  long hair_;
  long beard_;
  long glasses_;
  long voice_;
  long anim_;

  // animation start time
  long animStartTime_;

  // screen size
  int screenW_;
  int screenH_;

  // viewport placement
  int viewportX_;
  int viewportY_;
  int viewportW_;
  int viewportH_;

  // zoom mode
  bool zoom_;

  // background mode
  bool drawBackground_;

  // event queue
  enum eEvent {
    EVENT_CHANGE_FACE = 0,
    EVENT_CHANGE_HAIR,
    EVENT_CHANGE_BEARD,
    EVENT_CHANGE_GLASSES,
    EVENT_ANIMATION,
    EVENT_PREPARE_SPEECH,
    EVENT_SPEECH,
    EVENT_NUM,
  };
  struct Event {
    eEvent event;
    const char *path;
    const char *path2;
  };
  static const int MAX_EVENT_QUEUE = 8;
  Event eventQueue_[MAX_EVENT_QUEUE];
  int nEvent_;
  QMutex eventQueueLock_;

  // media player
#ifdef USE_QMEDIAPLAYER
  QMediaPlayer mediaPlayer_;
  QMediaContent mediaContentSpeech_;
#else
  QSound *soundVoice_;
  QSound *soundAnim_;
#endif

  // private methods
  void queueEvent(eEvent id, const char *path);
  void queueEvent(eEvent id, const char *path, const char *path2);
  void handleEvent();

  void doChangeFace(const char *dataPath);
  void doChangeHair(const char *dataPath);
  void doChangeBeard(const char *dataPath);
  void doChangeGlasses(const char *dataPath);
  void doCloseEye();
  void doPrepareSpeech(const char *dataPath);
  void doSpeech();
  void doAnimation(const char *dataPath, const char *extraDataPath);
  void doCancelAnimation();

  int loadFace(const char *path);
  int loadItem(const char *path, motionportrait::MpCtlItem *ctl, long *item);

  void stopSound();
  void prepareSpeechSound(const char *soundFilePath);
  void playSpeechSound();
  void playAnimSound(const char *soundFilePath);
  void cleanupSound();
};

#endif  // MP_AVATAR_H
